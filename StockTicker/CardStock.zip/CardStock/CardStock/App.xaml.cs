﻿using System.Windows;

namespace Jarloo.CardStock
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
